<link rel="stylesheet" href="valid_style.css">
<?php 
  function check_options(string $option){
    if($option=="No"){
      $msg="Thank You For Your trust..";
      return $msg;
    }
    elseif($option=="Yes"){
      $msg="Thank You for trusting us again with your health needs";
      return $msg;
    }
  }
  function check_dept(string $dept){
    switch ($dept) {
      case 'Anesthesiologist':
        return "Dr Mistry";
      case 'Neurologist':
        return "Dr Brick Wall";
      case 'Cardiologist':
        return "Dr Truluck";
      case 'Surgeon':
       return "Dr Hart";
      case 'Anesthesiology':
       return "Dr Palmer";
      default:
        return NULL;
    }
  }
  function check_num(int $no){
    $num=$no;
    $count=0;
     while($no != 0){
    $no = (int)($no / 10);
    $count++;
  }
    if($count==10){
      return $num;
    }
   else
    return NULL;
  }
  function cal_fees($pro){
    if($pro=="Medical Examination")
      return "$250";
    elseif($pro=="Doctor Check")
      return "$350";
    elseif($pro=="Report Analysis")
      return "$150";
    elseif($pro=="CheckUp")
      return "$550";
  }
  function amt_cal($qty){
    $amt=30;
    for($i=1;$i<=$qty;$i++)
      $amt=($amt+$i);
    return $amt;
  }

  function receipt($n,$age,$gender,$ph,$dept,$date,$d,$pro,$fees,$token,$med,$amt){
    $image="hospital.png";
    print"<img src=\"$image\" width=\"150px\" height=\"150px\"\/>";
    echo "<h1 class'hospital'>ACHME CARE</h1>";
    echo "<h3 class='hospital_name'><b><u>ACHME CARE HOSPITAL</u></b></h3>";
    echo "<p class='address'>123 Maple Street,<br> Houston, Tx 77002,<br>achmeclinic@gmaiil.com,<br>(123) 1234567</p>";
    echo "<hr>";
    echo "<h2 class='head'>WEB APPOINTMENT</h2>";
    echo "<dl class='details'>
  <dt><b>Username&nbsp</b></dt>
  <dd>".$n."</dd><br>
  <dt><b>Age&nbsp &nbsp</b></dt>
  <dd>".$age."</dd><br>
  <dt><b>Gender&nbsp</b></dt>
  <dd>",$gender."</dd><br>
  <dt><b>Mobile&nbsp</b></dt>
  <dd>",$ph."</dd><br>
  <dt><b>Department&nbsp</b></dt>
  <dd>".$dept."</dd><br>
  <dt><b>Doctor&nbsp</b></dt>
  <dd>".$d."</dd><br>
  <dt><b>Pref.Date&nbsp</b></dt>
  <dd>".$date."</dd><br>
  <dt><b>Procedure&nbsp</b></dt>
  <dd>".$pro."</dd><br>
  <dt><b>Fees&nbsp&nbsp</b></dt>
  <dd>".$fees."</dd><br>
  <dt><b>Token_Id&nbsp&nbsp</b></dt>
  <dd>".$token."</dd><br>
  <dt><b>Medicine&nbsp&nbsp</b></dt>
  <dd>".$med."</dd><br>
  <dt><b>Amount(Inc.GST)&nbsp&nbsp</b></dt>
  <dd>".$amt."</dd><br>
  </dl>";
  success();
  echo "<button onclick='window.print()'>Print</button>";
  }
  function error(){
    echo "<p class='error'>Check The Credentials* Entered !</p>";
  }
  function success(){
    echo "<p class='success'>Booked Successfully !!</p>";
    echo "<p class='visit'>Visit along with this receipt*<br>";
    $image2="booked.png";
    print"<img src=\"$image2\" width=\"150px\" height=\"150px\"\/ class='book'>";
  }
  $option = $_POST['options'];
  $m =check_options($option);
  $dept=$_POST['department'];
  $d=check_dept($dept);
  $name=$_POST['name'];
  $no=$_POST['number'];
  $ph=check_num($no);
  $date=$_POST['Dates'];
  $age=$_POST['age'];
  $gender=$_POST['gender'];
  $pro=$_POST['pro'];
  $fees=cal_fees($pro);
  $token=(rand(10,100));
  $med=$_POST['med'];
  $qty=$_POST['qty'];
  $a=amt_cal($qty);
  if( $ph==NULL || $d==NULL )
    error();
  else
    receipt($name,$age,$gender,$ph,$dept,$date,$d,$pro,$fees,$token,$med,$a);

?>