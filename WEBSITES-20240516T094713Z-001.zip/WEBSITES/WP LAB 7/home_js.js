function login() {
  let x = document.forms["form"]["username"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  else if (/\d/.test(x)==true)
  {
        alert("Invalid username");
        return false;
  }
}
