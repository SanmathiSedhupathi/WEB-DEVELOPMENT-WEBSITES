const form = document.getElementById('form');
const Quantity = document.getElementById('qty');
const Postal = document.getElementById('postal');
const Mobile = document.getElementById('mobile');
const Dates = document.getElementById('date');

form.addEventListener('submit', e => {
    e.preventDefault();
    validateInputs();
});
function setError(element, message){
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success')
}

function setSuccess(element){
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = '';
    inputControl.classList.add('success');
    inputControl.classList.remove('error');
};
function validatePostal(n){
   let count = 0;
    while (n != 0) 
    {
        n = Math.floor(n / 10);
        ++count;
    }

  if(count==6)
    return true;
else
    return false;
}
function validateMobile(mbl){
 var phoneno = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
  if(mbl.match(phoneno))
      return true;
  else
     return false;
}
function validatedate(date){
    var curr = new Date().toJSON().slice(0, 10);
    if(curr<date)
        return true;
    else
        return false;
}
function validateInputs(){
    const QuantityVal = Quantity.value.trim();
    const PostalCode = Postal.value.trim();
    const MobileNo = Mobile.value.trim();
    const Gndate = Dates.value.trim();
    if(QuantityVal<=0)
        alert('Invalid Quantity');
    if(!validatePostal(PostalCode))
        alert('Postal Code contains only 6 digits');
    if(!validateMobile(MobileNo))
        alert('Invalid Mobile Number');
    if(!validatedate(Gndate))
        setError(Dates,'Invalid Date');
};