const form = document.getElementById('form');
const cvv = document.getElementById('cvv');
const date = document.getElementById('validtill');
const Card = document.getElementById('cardno');

form.addEventListener('submit', e => {
    e.preventDefault();
    validateInputs();
});

function validatecvv(cvv) {
	let count = 0;
    while (cvv!= 0) 
    {
        cvv = Math.floor(cvv / 10);
        ++count;
    }
  if(count==3)
  	return true;
  else
  	return false;
}
function validatedate(c){
	var currentTime = new Date();
	var year = currentTime.getFullYear();
	if(c>year)
		return true;
	else
		return false;
}

function validateInputs(){
    const CVV = cvv.value.trim();
    const Dates=date.value.trim();
    const card=Card.value.trim();
    if(!validatedate(Dates))
    	alert('Invalid Date');
    else if(Dates=="")
    	alert('Date cannot be empty')
    if(!validatecvv(CVV))
    	 alert('Invalid CVV');
    else if(cvv=="")
        alert('cvv cannot be empty')
    if(!(Number.isInteger(card)))
    	alert('Card Number is invalid');
    else
        return false;

 };
