function start(){
	document.getElementById("new").addEventListener("click",create,false);
	document.getElementById("movie").addEventListener("click",createtext,false);
	document.getElementById("lists").addEventListener("click",insertbefore,false);
	document.getElementById("replace").addEventListener("click",replace,false);
	document.getElementById("remove").addEventListener("click",remove,false);
	document.getElementById("get").addEventListener("click",getattribute,false);
	document.getElementById("set").addEventListener("click",setattribute,false);
	document.getElementById("lang").addEventListener("click",language,false);

}
window.addEventListener("load",start,false);
function create(){
	let image = document.createElement("img");
	image.src = "movie1.jpg";
	image.style.height = "250";
	image.style.width = "250px";
	image.style.position="relative";
	image.style.top="800px";
	image.style.left="50px";
	document.body.appendChild(image);
}
function createtext(){
	var textNode = document.createTextNode("Dream without Limits");
	var spanElement = document.createElement("span");
	 spanElement.className = "moviename";
	 spanElement.appendChild(textNode);
	document.body.appendChild(spanElement);
}
function insertbefore(){
	const newNode=document.createElement("li");
	const textNode=document.createTextNode("FREEDOM FIGHTERS");
	newNode.appendChild(textNode);
	const list=document.getElementById("m");
	list.insertBefore(newNode,list.children[1]);
}
function replace() {
	const element = document.createElement("li");
	const newNode = document.createTextNode("THE VAMPIRE DIARIES");
	element.appendChild(newNode);
	const list=document.getElementById("m");
	list.replaceChild(element, list.children[0]);
}
function remove() {
	var image_x = document.getElementById('image_X');
	image_x.parentNode.removeChild(image_x);
}
function getattribute(){
	const element=document.getElementById("hero");
	let text=element.getAttribute("class");
	document.getElementById("demo").innerHTML = text;
}
function setattribute(){
	document.getElementById("myH1").setAttribute("class", "democlass");
}
function language() {
	let text = document.getElementById("lan").lang;
	document.getElementById("de").innerHTML = text;
}