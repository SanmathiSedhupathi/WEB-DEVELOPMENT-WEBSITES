<?php
$regex_name = "/^[a-zA-Z\s]+$/"; 
$regex_email = "/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/"; // Email pattern
$regex_phone = "/^\d{10}$/"; 
$regex_deposit="/^[1-9][0-9]{3,}$/";
$regex_dob="/^(19[0-9]{2}|200[0-3])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/";
$regex_aadhaar="/^\d{12}$/";
$regex_address="/^[#.0-9a-zA-Z\s,-]+$/"; //#1, North Street, Chennai - 11 
$regex_proof="/^([a-zA-Z0-9\s_\\.\-:])+(.doc|.docx|.pdf)$/";

$nameErr = $emailErr = $phoneErr = $depositErr = $dobErr=$aadhaarErr=$addressErr=$phoneErr=$proofErr='';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['name'])) {
        $nameErr = 'Name is required.';
    } elseif (!preg_match($regex_name, $_POST['name'])) {
        $nameErr = 'Only alphabets and spaces are allowed.';
    } else {
        $name = $_POST['name'];
    }
    if (empty($_POST['email'])) {
        $emailErr = 'Email is required.';
    } elseif (!preg_match($regex_email, $_POST['email'])) {
        $emailErr = 'Invalid email format.';
    } else {
        $email = $_POST['email'];
    }
    if (empty($_POST['phone'])) {
        $phoneErr = 'Phone number is required.';
    } elseif (!preg_match($regex_phone, $_POST['phone'])) {
        $phoneErr = 'Invalid phone number format (10 digits only).';
    } else {
        $phone = $_POST['phone'];
    }
    if (empty($_POST['initial-deposit'])) {
        $depositErr = 'Deposit Amount  is required.';
    } elseif (!preg_match($regex_deposit, $_POST['initial-deposit'])) {
        $depositErr = 'Deposit Amount should to be greater than 1000';
    } else {
        $deposit = $_POST['initial-deposit'];
    }
     if (empty($_POST['dob'])) {
        $dobErr = 'Date of Birth is required.';
    } elseif (!preg_match($regex_dob, $_POST['dob'])) {
        $dobErr = 'Age should be greater than 18';
    } else {
        $name = $_POST['dob'];
    }
     if (empty($_POST['aadhaar'])) {
        $aadhaarErr = 'Aadhar Number is required.';
    } elseif (!preg_match($regex_aadhaar, $_POST['aadhaar'])) {
        $aadhaarErr = 'Invalid Aadhaar number format (12 digits only).';
    } else {
        $name = $_POST['aadhaar'];
    }
    if (empty($_POST['address'])) {
        $addressErr = 'Address is required';
    } elseif (!preg_match($regex_address, $_POST['address'])) {
        $addressErr = 'Invalid address.';
    } else {
        $name = $_POST['aadhaar'];
    }
    if (empty($_POST['proof'])) {
        $proofErr = 'Proof is required';
    } elseif (!preg_match($regex_proof, $_POST['proof'])) {
        $proofErr = 'Invalid file format(.doc,.docx,.pdf)';
    } else {
        $name = $_POST['proof'];
    }
    if (empty($nameErr) && empty($emailErr) && empty($phoneErr) && empty($depositErr) && empty($dobErr) && empty($aadhaarErr) && empty($addressErr) && empty($proofErr)) {
        echo "<center><h1 style='color:green;size:25px;'>Submitted Successfully</h1></center>";
        exit();
    }
    else{
    	echo $nameErr."<br/>";
        echo $emailErr."<br/>";
        echo $phoneErr."<br/>";
        echo $addressErr."<br/>";
        echo $dobErr."<br/>";
        echo $depositErr."<br/>";
        echo $proofErr."<br/>";

    }
  }



?>